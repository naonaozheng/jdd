## 禁止Star/Fork!!
## 请勿使用Action运行脚本!
## 有条（科学）件（上网）的可以 [点此加入组织](https://t.me/jd_zero_205)  

## 本仓库部分脚本已加入JDHelloWorld大佬助力池，默认加入助力池互助
## 由于限制TG群内成员提交助力码，请需要互助的 [加入组织](https://t.me/jd_zero_205)，获取使用[教程](https://t.me/jd_zero205_tz/53)
## 不需要助力池请添加环境变量，变量名：`JD_JOIN_ZLC`，变量值：`false`  

## 请勿直接fork！！云函数用户先按照下方教程建立私库！！！
## 已经创建公开仓库的请点击仓库右上角`Setting`，拉到页面最下方，点击`Change visibility`，选择`Make private`，填入黑体仓库名称进行确认!

## 使用教程

### 【青龙】拉取仓库命令：
可以直链github/国外机:`ql repo https://github.com/zero205/JD_tencent_scf.git "jd_|jx_|jdCookie"  "backUp|icon" "^jd[^_]|USER|sendNotify|sign_graphics_validate|JDJR|JDSign|ql" "main"`

国内镜像(部分人不可用):

`ql repo https://github.com.cnpmjs.org/zero205/JD_tencent_scf.git "jd_|jx_|jdCookie"  "backUp|icon" "^jd[^_]|USER|sendNotify|sign_graphics_validate|JDJR|JDSign|ql" "main"`

(直连/镜像均不可用时,请参照下面使用直连命令并设置代理)

设置代理/国内加速:

老版青龙(临时解决),需要设置config.sh(如果还有extra.sh的话,也改)中的GithubProxyUrl改为
https://pd.zwc365.com/ 或 https://pd.zwc365.com/cfworker/

新版青龙可以改ProxyUrl为自己的科学上网代理,来走自己的代理

或者直接将上面两个代理地址追加到url之前来临时解决
`ql repo https://pd.zwc365.com/https://github.com/zero205/JD_tencent_scf.git "jd_|jx_|jdCookie"  "backUp|icon" "^jd[^_]|USER|sendNotify|sign_graphics_validate|JDJR|JDSign|ql" "main"``

[高级用户,可以自己创建自己的cf woker做git代理(注意将cnpmjs设为0)](https://github.com/hunshcn/gh-proxy#cf-worker%E7%89%88%E6%9C%AC%E9%83%A8%E7%BD%B2)

[或者尝试修改host来尝试直连](https://www.cnblogs.com/jiannanchun/p/15397235.html)

### 腾讯云函数部署建议阅读@hshx123大佬的[教程](https://杏铃.top/teach/jd.html)【推荐】.[旧教程](./backUp/tencentscf.md)【备用】

### [elecV2P](https://github.com/elecV2/elecV2P) 部署【随缘维护，建议转战➟[Docker](https://www.runoob.com/docker/windows-docker-install.html) [青龙](https://github.com/whyour/qinglong)】
    * 安装教程：[点此查看](https://github.com/elecV2/elecV2P-dei/blob/master/docs/01-overview.md)  
    * 订阅任务：`https://ghproxy.com/https://raw.githubusercontent.com/zero205/JD_tencent_scf/main/jd_task.json`
    * elecV2P京东CK、通知填写格式等相关补充说明：[点此查看](./backUp/elecV2P.md)  

### 获取京东cookie教程可参考：
  
  + [浏览器获取京东cookie教程](./backUp/GetJdCookie.md)
    
  + [插件获取京东cookie教程](./backUp/GetJdCookie2.md)
   
  + [浏览器扩展程序获取京东cookie教程](./backUp/GetJdCookie3.md)

## 特别声明: 

* 本仓库发布的Script项目中涉及的任何解锁和解密分析脚本，仅用于测试和学习研究，禁止用于商业用途，不能保证其合法性，准确性，完整性和有效性，请根据情况自行判断.

* 本项目内所有资源文件，禁止任何公众号、自媒体进行任何形式的转载、发布。

* lxk0301对任何脚本问题概不负责，包括但不限于由任何脚本错误导致的任何损失或损害.

* 间接使用脚本的任何用户，包括但不限于建立VPS或在某些行为违反国家/地区法律或相关法规的情况下进行传播, lxk0301 对于由此引起的任何隐私泄漏或其他后果概不负责.

* 请勿将Script项目的任何内容用于商业或非法目的，否则后果自负.

* 如果任何单位或个人认为该项目的脚本可能涉嫌侵犯其权利，则应及时通知并提供身份证明，所有权证明，我们将在收到认证文件后删除相关脚本.

* 任何以任何方式查看此项目的人或直接或间接使用该Script项目的任何脚本的使用者都应仔细阅读此声明。lxk0301 保留随时更改或补充此免责声明的权利。一旦使用并复制了任何相关脚本或Script项目的规则，则视为您已接受此免责声明.

 **您必须在下载后的24小时内从计算机或手机中完全删除以上内容.**  </br>
> ***您使用或者复制了本仓库且本人制作的任何脚本，则视为`已接受`此声明，请仔细阅读***   

## 环境变量
- [环境变量集合](./githubAction.md)

## 特别感谢(排名不分先后)：


* [@NobyDa](https://github.com/NobyDa)

* [@chavyleung](https://github.com/chavyleung)

* [@liuxiaoyucc](https://github.com/liuxiaoyucc)

* [@Zero-S1](https://github.com/Zero-S1)

* [@uniqueque](https://github.com/uniqueque)

* [@nzw9314](https://github.com/nzw9314)

* [@JDHelloWorld](https://github.com/JDHelloWorld)

* [@smiek2221](https://github.com/smiek2221)

* [@star261](https://github.com/star261)

* [@Wenmoux](https://github.com/Wenmoux)

* [@Tsukasa007](https://github.com/Tsukasa007)

* [@Aaron](https://github.com/Aaron)
